$(function() {
	var seckill_hh = 1;
	var seckill_mm = 1;
	var seckill_ss = 5;
	setInterval(function() {
		if(seckill_mm == 0){
			seckill_hh = seckill_hh - 1;
			seckill_mm = 60;
			seckill_ss = 60;
		}
		if(seckill_ss == 0){
			seckill_mm = seckill_mm - 1;
			seckill_ss = 60
		}
		seckill_ss--;
		if(seckill_hh < 9)
			$(".body_rec_seckill_info_time_hh")[0].innerHTML = "0" + seckill_hh;
		else
			$(".body_rec_seckill_info_time_hh")[0].innerHTML = seckill_hh;
		if(seckill_mm< 9 )
			$(".body_rec_seckill_info_time_mm")[0].innerHTML = "0" + seckill_mm;
		else
			$(".body_rec_seckill_info_time_mm")[0].innerHTML = seckill_mm;
		if(seckill_ss < 9)
			$(".body_rec_seckill_info_time_ss")[0].innerHTML = "0" + seckill_ss;
		else
			$(".body_rec_seckill_info_time_ss")[0].innerHTML = seckill_ss;
	}, 1000)
})
