// $(function() {
// 	$("#head_my_jd").hover(
// 			$('#head_my_jd').show(),
// 			$('#head_my_jd').hide();
// 	});
// });
//地区下拉

function show_down_area() {
	$('#head_down_area').show();
	$('.head_title_area').css("background-color", "#FFFFFF");
	$('.head_title_area').css("border-top", "1px solid #CCCCCC");
	$('.head_title_area').css("border-left", "1px solid #CCCCCC");
	$('.head_title_area').css("border-right", "1px solid #CCCCCC");
};


function hide_down_area() {
	$('#head_down_area').hide();
	$('.head_title_area').css("background-color", "#E3E4E5");
	$('.head_title_area').css("border", "1px solid transparent");
};

// 鼠标划过下拉框的省份
function show_area_bgc(i) {
	if (document.getElementById("c_area").name != "area_" + i)
		$('.head_area_item_' + i).css("background-color", "#F4F4F4");
};

function hide_area_bgc(i) {
	if (document.getElementById("c_area").name != "area_" + i)
		$('.head_area_item_' + i).css("background-color", "#FFFFFF");
};

//更新选择的地区
function upd_area(i) {
	$('.head_area_item_all').css("background-color", "#FFFFFF");
	$('.head_area_item_all').css("color", "#FF0000");
	document.getElementById("c_area").innerHTML = "@" + $('.head_area_item_' + i).children()[0].innerHTML;
	document.getElementById("c_area").name = "area_" + i;
	$('.head_area_item_' + i).css("background-color", "#F10215");
	$('.head_area_item_' + i).css("color", "#FFFFFF");

};

// 我的京东下拉
function show_my_jd() {
	$('#head_my_jd').show();
	$('.head_my_jd').css("background-color", "#FFFFFF");
	// $('.head_my_jd').css("width"," 50px");
	// $('.head_my_jd').css("height", "29px");
	$('.head_my_jd').css("padding-top", "10px");
	$('.head_my_jd').css("padding-bottom", "8px");
	$('.head_my_jd').css("border-top", "1px solid #CCCCCC");
	$('.head_my_jd').css("border-left", "1px solid #CCCCCC");
	$('.head_my_jd').css("border-right", "1px solid #CCCCCC");
};

function hide_my_jd() {
	$('#head_my_jd').hide();
	$('.head_my_jd').css("background-color", "#E3E4E5");
	$('.head_my_jd').css("border", "1px solid transparent");
};

//企业采购下拉
function show_my_firm() {
	$('#head_my_firm').show();
	$('.head_my_firm').css("background-color", "#FFFFFF");
	$('.head_my_firm').css("padding-top", "10px");
	$('.head_my_firm').css("padding-bottom", "8px");
	$('.head_my_firm').css("border-top", "1px solid #CCCCCC");
	$('.head_my_firm').css("border-left", "1px solid #CCCCCC");
	$('.head_my_firm').css("border-right", "1px solid #CCCCCC");
};

function hide_my_firm() {
	$('#head_my_firm').hide();
	$('.head_my_firm').css("background-color", "#E3E4E5");
	$('.head_my_firm').css("border", "1px solid transparent");
};

//客户服务下拉
function show_my_clent() {
	$('#head_my_clent').show();
	$('.head_my_clent').css("background-color", "#FFFFFF");
	$('.head_my_clent').css("padding-top", "10px");
	$('.head_my_clent').css("padding-bottom", "8px");
	$('.head_my_clent').css("border-top", "1px solid #CCCCCC");
	$('.head_my_clent').css("border-left", "1px solid #CCCCCC");
	$('.head_my_clent').css("border-right", "1px solid #CCCCCC");
};

function hide_my_clent() {
	$('#head_my_clent').hide();
	$('.head_my_clent').css("background-color", "#E3E4E5");
	$('.head_my_clent').css("border", "1px solid transparent");
};

//网站导航下拉
function show_web_nav() {
	$('#head_web_nav').show();
	$('.head_web_nav').css("background-color", "#FFFFFF");
	$('.head_web_nav').css("padding-top", "10px");
	$('.head_web_nav').css("padding-bottom", "8px");
	$('.head_web_nav').css("border-top", "1px solid #CCCCCC");
	$('.head_web_nav').css("border-left", "1px solid #CCCCCC");
	$('.head_web_nav').css("border-right", "1px solid #CCCCCC");
};

function hide_web_nav() {
	$('#head_web_nav').hide();
	$('.head_web_nav').css("background-color", "#E3E4E5");
	$('.head_web_nav').css("border", "1px solid transparent");
};

//手机京东
function show_mobile_jd() {
	$('.head_jd_qrcodes').show();
	$('.head_jd_qrcodes').css("display", "block");
};

function hide_mobile_jd() {
	$('.head_jd_qrcodes').hide();
};

//鼠标划过搜索按钮
function head_c_serch() {
	$('.head_serch_button').css("background-color", "#C81623");
};

function head_c_serch_up() {
	$('.head_serch_button').css("background-color", "#E1251B");
};

$(function(){
	//鼠标划过相机
	$('.head_serch_xj_a').mouseenter(function() {
		$($(this)[0].getElementsByTagName("img")[0]).css("display", "none");
		$($(this)[0].getElementsByTagName("img")[1]).css("display", "inline-block");
	});
	
	$('.head_serch_xj_a').mouseleave(function() {
		$($(this)[0].getElementsByTagName("img")[0]).css("display", "inline-block");
		$($(this)[0].getElementsByTagName("img")[1]).css("display", "none");
	});
})


function head_my_car_c() {
	// head_serch_my_car
}
