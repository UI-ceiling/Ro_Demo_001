$(function() {
	//大轮播广告
	var rotate_index = 0;
	var rotate_timer = null;

	// 定时器自动播放 大广告
	function rotateSliderTimer() {
		rotate_timer = setInterval(function() {
			rotate_index++;
			if (rotate_index == $('.body_rotate_img_item').length) {
				rotate_index = 0;
			}
			rotateSliderIndex(rotate_index);
			//console.log(2);
		}, 2000)
	}
	rotateSliderTimer();

	// 根据索引值点亮小圆点并显示对应图片
	function rotateSliderIndex(rotate_index) {
		// 对应图片显示
		$('.body_rotate_img_item').eq(rotate_index).fadeIn(0).siblings().fadeOut(0);
		// 小圆点点亮
		$('.body_rotate_dot_li').eq(rotate_index)
			.addClass('body_rotate_dot_li_show')
			.siblings()
			.removeClass('body_rotate_dot_li_show');
	}
	// 小圆点鼠标悬浮事件
	$('.body_rotate_dot_li').mouseenter(function() {
		clearInterval(rotate_timer);
		rotate_index = $(this).index();
		rotateSliderIndex(rotate_index);
	})
	// 左侧按钮点击事件
	$('.body_rotate_l').click(function() {
		rotate_index--;
		if (rotate_index == -1) {
			rotate_index = $('.body_rotate_img_item').length - 1;
		}
		rotateSliderIndex(rotate_index)
	})
	// 右侧按钮点击事件
	$('.body_rotate_r').click(function() {
		rotate_index++;
		if (rotate_index == $('.body_rotate_img_item').length) {
			rotate_index = 0;
		}
		rotateSliderIndex(rotate_index)
	})
	// 鼠标移入轮播区域关闭定时器
	$('.body_rotate_all').mouseenter(function() {
		clearInterval(rotate_timer);
	})
	// 鼠标移出轮播区域开启定时器
	$('.body_rotate_all').mouseleave(function() {
		rotateSliderTimer();
	})

	$(".body_menu_left_item").on("mouseover",
		function() {
			$('.body_menu_left_hover').css("display", "inline-block");
		}).on("mouseleave",
		function() {
			$('.body_menu_left_hover').css("display", "none");
		});
	$(".body_menu_left_hover").on("mouseover",
		function() {
			$('.body_menu_left_hover').css("display", "inline-block");
		}).on("mouseleave",
		function() {
			$('.body_menu_left_hover').css("display", "none");
		});
	//


	//右侧小轮播广告
	var adv_index = 0;
	var adv_timer = null;
	//小广告


	function advSliderTimer() {
		adv_timer = setInterval(function() {
			adv_index++;
			if (adv_index == $('.body_little_adv_ul').length) {
				adv_index = 0;
			}
			advSliderIndex(adv_index)
		}, 5000)
	}
	advSliderTimer();

	$('.body_little_adv_ul_l').click(function() {
		adv_index--;
		if (adv_index == -1) {
			adv_index = $('.body_little_adv_ul').length - 1;
		}
		clearInterval(adv_timer);
		advSliderTimer();
		advSliderIndex(adv_index);
	})
	// 右侧按钮点击事件
	$('.body_little_adv_ul_r').click(function() {
		adv_index++;
		if (adv_index == $('.body_little_adv_ul').length) {
			adv_index = 0;
		}
		clearInterval(adv_timer);
		advSliderTimer();
		advSliderIndex(adv_index);
	})

	function advSliderIndex(adv_index) {
		// 对应图片显示
		$('.body_little_adv_ul').eq(adv_index).fadeIn(0).siblings().fadeOut(0);
		$('.body_little_adv_ul_l').css("display", "block");
		$('.body_little_adv_ul_r').css("display", "block");
	}

	// 鼠标移入显示向左向右
	$('.body_little_adv_all').mouseenter(function() {
		$('.body_little_adv_ul_l').css("display", "block");
		$('.body_little_adv_ul_r').css("display", "block");
	})
	$('.body_little_adv_ul_l').mouseenter(function() {
		$('.body_little_adv_ul_l').css("display", "block");
		$('.body_little_adv_ul_r').css("display", "block");
	})
	$('.body_little_adv_ul_r').mouseenter(function() {
		$('.body_little_adv_ul_l').css("display", "block");
		$('.body_little_adv_ul_r').css("display", "block");
	})
	$('.body_little_adv_ul_l').mouseenter(function() {
		$('.body_little_adv_ul_l').css("display", "block");
		$('.body_little_adv_ul_r').css("display", "block");
	})

	// 鼠标移出隐藏向左向右
	$('.body_little_adv_all').mouseleave(function() {
		$('.body_little_adv_ul_l').css("display", "none");
		$('.body_little_adv_ul_r').css("display", "none");
	})


	// 鼠标移入显示遮罩
	$('.body_little_adv_li').mouseenter(function() {
		$(this).css("opacity", "0.85");
	})
	// 鼠标移出隐藏遮罩
	$('.body_little_adv_li').mouseleave(function() {
		$(this).css("opacity", "1");
	})

	//右侧小导航
	$('.body_my_service td').mouseenter(function() {
		$($(this)[0].getElementsByTagName("img")[0]).css("display", "none");
		$($(this)[0].getElementsByTagName("img")[1]).css("display", "inline-block");
		$($(this)[0].getElementsByTagName("span")[0]).css("color", "#C81623");
		//$('.body_my_service_buy').css("display", "block");
	})
	$('.body_my_service td').mouseleave(function() {
		$($(this)[0].getElementsByTagName("img")[0]).css("display", "inline-block");
		$($(this)[0].getElementsByTagName("img")[1]).css("display", "none");
		$($(this)[0].getElementsByTagName("span")[0]).css("color", "#333333");
	})
	
	$('.body_my_service_buy').mouseleave(function() {
		$('.body_my_service_buy').css("display", "none");
	})
})

/* function aaa() {
	console.log(1);
	$('.body_my_service_buy').css("display", "none");
} */
